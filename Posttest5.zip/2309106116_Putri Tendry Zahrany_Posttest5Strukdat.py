class Panitia:
    def __init__(self, nama, jabatan, umur):
        self.nama = nama
        self.jabatan = jabatan
        self.umur = umur
        self.next = None


class DaftarKepanitiaan:
    def __init__(self):
        self.head = None
    
    def tambah_panitia(self, nama, jabatan, umur):
        anggota_baru = Panitia(nama, jabatan, umur)
        if self.head is None:
            self.head = anggota_baru
        else:
            temp = self.head
            while temp.next:
                temp = temp.next
            temp.next = anggota_baru
    
    def tampilkan_daftar(self):
        if self.head is None:
            print("Daftar kepanitiaan kosong.")
        else:
            temp = self.head
            while temp:
                print(f"Nama: {temp.nama}, Jabatan: {temp.jabatan}, Umur: {temp.umur}")
                temp = temp.next

def merge_sort_ascending(head):
    if head is None or head.next is None:
        return head

    middle = get_middle(head)
    next_to_middle = middle.next
    middle.next = None

    left = merge_sort_ascending(head)
    right = merge_sort_ascending(next_to_middle)

    sorted_list = sorted_merge_ascending(left, right)
    return sorted_list

def sorted_merge_ascending(left, right):
    if left is None:
        return right
    if right is None:
        return left

    if left.nama <= right.nama:
        result = left
        result.next = sorted_merge_ascending(left.next, right)
    else:
        result = right
        result.next = sorted_merge_ascending(left, right.next)
    return result

def get_middle(head):
    if head is None:
        return head

    slow = head
    fast = head

    while fast.next and fast.next.next:
        slow = slow.next
        fast = fast.next.next

    return slow

def quick_sort_descending(head):
    if head is None or head.next is None:
        return head

    pivot = head
    less_head, equal_head, greater_head = partition_descending(head, pivot)

    less_sorted = quick_sort_descending(less_head)
    greater_sorted = quick_sort_descending(greater_head)

    return concatenate_descending(greater_sorted, equal_head, less_sorted)

def partition_descending(head, pivot):
    less_head = None
    equal_head = None
    greater_head = None

    while head:
        if head.nama > pivot.nama:
            greater_head = add_to_list(greater_head, head)
        elif head.nama < pivot.nama:
            less_head = add_to_list(less_head, head)
        else:
            equal_head = add_to_list(equal_head, head)
        head = head.next

    return less_head, equal_head, greater_head

def add_to_list(head, node):
    if head is None:
        head = node
        node.next = None
    else:
        temp = head
        while temp.next:
            temp = temp.next
        temp.next = node
        node.next = None
    return head

def concatenate_descending(greater_head, equal_head, less_head):
    if greater_head is None:
        if equal_head is None:
            return less_head
        equal_head.next = less_head
        return equal_head
    else:
        temp = greater_head
        while temp.next:
            temp = temp.next
        temp.next = equal_head
        if equal_head:
            equal_head.next = less_head
        else:
            temp.next = less_head
        return greater_head

def urutkan_daftar(daftar, mode="ascending"):
    if mode == "ascending":
        daftar.head = merge_sort_ascending(daftar.head)
    elif mode == "descending":
        daftar.head = quick_sort_descending(daftar.head)
    else:
        print("Mode sorting tidak dikenali.")

# Main program
daftar_panitia = DaftarKepanitiaan()

# Menambahkan data panitia
daftar_panitia.tambah_panitia("Putri", "Ketua", 21)
daftar_panitia.tambah_panitia("Tendry", "Wakil Ketua", 20)
daftar_panitia.tambah_panitia("Zahrany", "Sekretaris", 22)

# Urutkan daftar panitia secara ascending (nama)
print("\nDaftar setelah diurutkan secara ascending:")
urutkan_daftar(daftar_panitia, mode="ascending")
daftar_panitia.tampilkan_daftar()

# Urutkan daftar panitia secara descending (nama)
print("\nDaftar setelah diurutkan secara descending:")
urutkan_daftar(daftar_panitia, mode="descending")
daftar_panitia.tampilkan_daftar()
